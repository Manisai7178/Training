import java.sql.*;
import java.util.Scanner;

public class MainPage 
	{
	final static String URL="jdbc:oracle:thin:@localhost:1521:XE";
	final static String user="hr";
	final static String pass="hr";
	static Connection conn=null;
	public static void main(String[] args) throws SQLException 
	{
		
		try 
		{
			conn=DriverManager.getConnection(URL, user, pass);
			if (conn!=null) 
			{
			System.out.println("Connection established.");	
			}
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		while(true)
		{
		System.out.println("Welcome to Employee Portal");
		System.out.println("Please select an option");
		System.out.println("1.Add an Employee");
		System.out.println("2.Update an Employee");
		System.out.println("3.Delete an Employee");
		System.out.println("4.Search an Employee");
		System.out.println("5.View all Employees");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		
		switch (ch) 
		{
		case 1:System.out.println("Enter name,salary,designation:");
				String name=sc.next();
				double sal=sc.nextDouble();
				String desig=sc.next();
				String sql="insert into employee values(psno.nextval,?,?,?)";
				PreparedStatement ps=conn.prepareStatement(sql);
				ps.setString(1, name);
				ps.setDouble(2, sal);
				ps.setString(3, desig);
				int x=ps.executeUpdate();
				if(x>0)
				{
					System.out.println("Employee Added");
				}
				else
				{
					System.out.println("Employee could not be Added");
				}
				
		
				System.out.println("Employee Added.");			
				break;
		case 2:
			System.out.println("Enter the psno");
			int psno=sc.nextInt();
			System.out.println("Enter name,salary,designation:");
			name=sc.next();
			 sal=sc.nextDouble();
			desig=sc.next();
			String sql1="update employee set name=?,salary=?,designation=? where psno=?";
			PreparedStatement ps2=conn.prepareStatement(sql1);
			ps2.setString(1, name);
			ps2.setDouble(2, sal);
			ps2.setString(3, desig);
			ps2.setInt(4, psno);
			int i=ps2.executeUpdate();
			if (i>0) 
			{
				System.out.println("Employee Details Updated.");
			}
			else
			{
				System.out.println("Employee Details not Updated.");
			}
			
			break;
		case 3:
			System.out.println("Enter ps no");
			int psno3=sc.nextInt();
			
			try {
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery("Delete from employee where psno="+psno3);
				while(rs.next()==true)
				{
					
					System.out.println("Employee Deleted.");
				}
				} 
				catch (Exception e1) 
				{
				System.out.println(e1.getMessage());
				}
			break;
			
		case 4:
			System.out.println("Enter ps no");
			int psno1=sc.nextInt();
			
			try {
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery("select * from employee where psno="+psno1);
				while(rs.next())
				{
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "
					+rs.getDouble(3)+" "+rs.getString(4));
					System.out.println("Employee Found.");
				}
				} 
				catch (Exception e1) 
				{
				System.out.println(e1.getMessage());
				}
			break;
		case 5:
			System.out.println("View all Employees.");
			try {
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery("select * from employee");
				while(rs.next()==true)
				{
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "
					+rs.getDouble(3)+" "+rs.getString(4));
				}
				} 
				catch (Exception e) 
				{
				System.out.println(e.getMessage());
				
				}
			break;
			default:
					System.out.println("Exit");
				break;
		}

		}
	}

}
