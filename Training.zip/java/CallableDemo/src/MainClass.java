import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

public class MainClass
{
	public static void main(String[] args) throws SQLException 
	{
		final  String URL="jdbc:oracle:thin:@localhost:1521:XE";
		final  String user="hr";
		final  String pass="hr";
		Connection conn=null;
		conn=DriverManager.getConnection(URL, user, pass);	
		
		CallableStatement st=conn.prepareCall("{call empInsertProc(?,?,?,?)}");
		
		st.setString(1, "Sachin");
		st.setDouble(2, 70000);
		st.setString(3, "Senior Manager");
		
		st.registerOutParameter(4,Types.VARCHAR);
		
		
		st.executeUpdate();
		
		System.out.println(st.getString(4));

	}

}
