import java.util.*;
class CVowel{
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the word");
		String str=scan.nextLine();
		char ch[]=str.toCharArray();
		
		int count=0;
		
		for(int c:ch)
		{
			switch(c){
				case 'a':
				case 'A':
				case 'e':
				case 'E':
				case 'i':
				case 'I':
				case 'o':
				case 'O':
				case 'u':
				case 'U':
						count++;
						break;
			}
				
		}
		System.out.println(count);
	}
}