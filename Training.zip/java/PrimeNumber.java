//to list prime number upto the given last number

import java.util.*;
class PrimeNumber{
	
	static void prime(int i){
		int flag = 0;
		for(int i = 2; i <= n/2; i++){
			if(n%i==0){
				flag = 1;
				break;
			}
		}

		if(flag == 1)
			return 0;
		else
			return 1;
	}
	static void nprime(int n){
		int p;
		for(int i=2;i<=n;i++){
			p=prime(i);
			if(p==1)
				System.out.println(i+" ");
		}
	}
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the higher limit:");
		int high=scan.nextInt();
		nprime(high);
	}
}