import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;

public class Local 
{
	public static void main(String args[])
	{
		LocalDate date=LocalDate.now();
		System.out.println("Today is"+date);
		
		 LocalDate birthdate=LocalDate.of(1997, 9, 28);
		 System.out.println(birthdate);
		 
		 LocalTime time=LocalTime.now();
		 System.out.println("Time is"+time);
		 
		 LocalDate todayUS=
				 		LocalDate.now(ZoneId.of("America/Los_Angeles"));
		 System.out.println(todayUS);
		 
		 LocalTime time2=LocalTime.now(ZoneId.of("America/Los_Angeles"));
		 System.out.println(time2);
		 
		 LocalDateTime dt=LocalDateTime.now();
		 System.out.println(dt);
		 
		 LocalDateTime dt2=LocalDateTime.now(ZoneId.of("America/San_Diego"));
		 System.out.println(dt2);
		 
		 
		 
		 
		 
	}

}
