import java.util.List;
import java.util.ArrayList;


abstract class Shape{
	abstract void area();
}
class Rectangle extends Shape
{
	@Override
	public void area() 
	{
		System.out.println("Area of Rectangle");
	}
}
class AddCalculator
{
	public  int  add(int a,int b)
	{
	return a+b;
	}
	public  int  add(int a,int b,int c)
	{
	return a+b+c;
	}
	public  float  add(float a,int  b)
	{
	return a+b;
	}
	public  double  add(double a,int b)
	{
	return a+b;
	}
	public  double  add(int a,double b)
	{
	return a+b;
	}
	public  String  add(String a,String b)
	{
	return a+b;
	}
}

public class AnnotationDemo
{
	@SuppressWarnings("unchecked")
	public static void main(String[] args) 
	{
		//List list=new ArrayList();
		
		AddCalculator ac=new AddCalculator();
		System.out.println(ac.add(5.2f, 4));
		System.out.println(ac.add(10, 4));
		System.out.println(ac.add(28, 9,97)); 
		System.out.println(ac.add("Mani", "sai"));
		
	}

}
