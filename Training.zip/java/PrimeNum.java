//to list prime number upto the given last number

import java.util.*;
class PrimeNum{
	static void nprime(int low,int high){
		while(low<high){
			boolean flag=false;
			
			for(int i=2;i<low/2;i++)
			{
				if(low%2==0){
					flag=true;
					break;
				}
			}
			if(!flag){
				System.out.println(low+" ");
			}
			++low;
		}
	}
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the lower limit:");
		int low=scan.nextInt();
		System.out.println("Enter the higher limit:");
		int high=scan.nextInt();
		nprime(low,high);
	}
}