//WAP To find Coumpound Interest
//WAP To list Prime Numbers upto the given last number.

import java.util.Scanner;
class PrimeAndCI{
	public static Scanner sc = new Scanner(System.in);

	static void CompoundInterest(){
		double p, r, t, n;
		System.out.print("Enter Principal Amount(p): ");
		p = sc.nextFloat();
		System.out.print("\nEnter Rate of Interest(r): ");
		r = sc.nextFloat();
		System.out.print("\nEnter Time in years(t): ");
		t = sc.nextFloat();
		System.out.print("\nEnter Number of times compounded(n): ");
		n = sc.nextFloat();
		System.out.println("Compund Interest: "+ p * Math.pow( 1+((r/100)/n) , n*t ) );
	
		return;
	}

	static int isPrime(int n){
		int flag = 0;
		for(int i = 2; i <= n/2; i++){
			if(n%i==0){
				flag = 1;
				break;
			}
		}

		if(flag == 1)
			return 0;
		else
			return 1;
	}


	static void PrimeNumbers(){
		System.out.print("Enter Number: ");
		int n = sc.nextInt();
		int p;		
		System.out.println("\nThe prime numbers upto "+n+" are: ");
		for(int i = 2; i<=n; i++){
			p = isPrime(i);
			if(p == 1)
				System.out.print(i+" ");
		}
		return;
	}

	public static void main(String[] args){
		int o;
		while(true){
			System.out.print("\n----------------------MENU------------------\n\n1. Compund Interest \n2. Prime Numbers\n3. Exit \nEnter your choice: ");
			o = sc.nextInt();
			switch(o){
				case 1: CompoundInterest();
					break;
				case 2: PrimeNumbers();
					break;
				case 3: System.exit(0);
			}
		}
	}
}