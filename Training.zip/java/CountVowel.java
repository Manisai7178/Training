//to find the number of vowels 
import java.util.*;
class CountVowel{
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the word");
		String str=scan.nextLine();
		char ch[]=str.toCharArray();
		
		int count=0;
		
		for(int s:ch)
		{
			if(s=='a'|| s=='e'||s=='i'||s=='o'||s=='u'||s=='A'|| s=='E'||s=='I'||s=='O'||s=='U'){
				count++;
			}
				
		}
		System.out.println(count);
	}
}