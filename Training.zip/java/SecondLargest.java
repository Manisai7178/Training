//from array find the second largest element in array
import java.util.*;
class SecondLargest{
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=scan.nextInt();
		int arr[]=new int[n];
		for(int i=0; i<n;i++){
			arr[i]=scan.nextInt();
		}
		int a=arr[0];
		int b=arr[1];
		for(int i=0;i<n;i++)
		{
			if(arr[i]>a)
			{
				b=a;
				a=arr[i];
			}
			else if(arr[i]>b && arr[i]!=a)
			{
				b=arr[i];
			}
		}
		System.out.println("Second Largest number is"+b);
	}
}