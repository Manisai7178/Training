package com.lti;

public class Employee {
	private String psNo;
    private	String employeeName;
	private int employeeAge;
	private double salary;
	
	public Employee(){
		
	}
	public Employee(String psNo, String employeeName, int employeeAge){
		
	}
	public Employee(String psNo, String employeeName, int employeeAge, double salary) {
		this.psNo = psNo;
		this.employeeName = employeeName;
		this.employeeAge = employeeAge;
		this.salary = salary;
	}
	public String getPsNo() {
		return psNo;
	}
	public void setPsNo(String psNo) {
		this.psNo = psNo;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmployeeAge() {
		return employeeAge;
	}
	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void addAnEmployee(){
		Employee emp=new Employee();
		emp.setPsNo("10667161");
		emp.setEmployeeName("Disha");
		emp.setEmployeeAge(21);
		emp.setSalary(10000);
	}
	public void updateEmployeeDetails(){
		
	}
	public void removeAnEmployee(){
		
	}
	public void findAnEmployee(){
		
	}
	public void displayAllEmployee(){
		
	}
	
}
