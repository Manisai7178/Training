package com.lti;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Employee emp=new Employee();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1.Add an employee:");
		System.out.println("2.Update an employee:");
		System.out.println("3.Delete an employee:");
		System.out.println("4.Search an employee:");
		System.out.println("5.Display an employee:");
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		switch(ch){
			case 1:	
			case 2:
			case 3:
			case 4:
			case 5:
		}
	}

}
