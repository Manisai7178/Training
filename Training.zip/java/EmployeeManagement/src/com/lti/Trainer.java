package com.lti;

public class Trainer extends Employee {
	String tariningDomain;
	int trainingDuration;
	
	public Trainer() {
		super();
		
	}
	public Trainer(String psNo, String employeeName, int employeeAge, double salary) {
		super(psNo, employeeName, employeeAge, salary);
		
	}
	public Trainer(String psNo, String employeeName, int employeeAge) {
		super(psNo, employeeName, employeeAge);
		
	}
	public Trainer(String psNo, String employeeName, int employeeAge, double salary, String tariningDomain,
			int trainingDuration) {
		super(psNo, employeeName, employeeAge, salary);
		this.tariningDomain = tariningDomain;
		this.trainingDuration = trainingDuration;
	}
	public String getTariningDomain() {
		return tariningDomain;
	}

	public void setTariningDomain(String tariningDomain) {
		this.tariningDomain = tariningDomain;
	}

	public int getTrainingDuration() {
		return trainingDuration;
	}

	public void setTrainingDuration(int trainingDuration) {
		this.trainingDuration = trainingDuration;
	}	
}
