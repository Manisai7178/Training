import java.util.Scanner;

public class StrName {
	public static void main(String[] args) {
		String [] names=new String[5];
		Scanner scan=new Scanner(System.in);
		System.out.println("enter 5 values");
		for(int i=0;i<names.length;i++){
			names[i]=scan.nextLine();
		}
		
		for(int i=0;i<names.length;i++){
			System.out.println(names[i]+" "+names[i].length());
		}
		
	}
}
