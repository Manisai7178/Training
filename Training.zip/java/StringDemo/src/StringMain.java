
public class StringMain {

	public static void main(String[] args) {
		/*String str="Larsen and Tuobro";
		System.out.println("String value:"+str);
		
		char ch=str.charAt(5);
		System.out.println(ch);
		
		System.out.println(str.length());
	    char []chStr=str.toCharArray();
	    //String objects are immutable
	    //str=str+"Infotech";
	    str=str.concat("Infotech");
	    System.out.println(str);
	    */
		
		/*
		String name="India";
		String nm= new String("India");
		String nm1=new String("India");
		System.out.println(name.equals(nm));
		System.out.println(name==nm);
		System.out.println(nm.equals(nm1));
		System.out.println(nm==nm1);
		
		String name1="India";
		System.out.println(name.equals(name1));
		System.out.println(name==name1);
		*/
		
	    String []name=new String[5];
	    
	}

}
