import java.util.*;
public class SeatMap {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter number of rows and columns:");
		int x=scan.nextInt();
		int y=scan.nextInt();
		int [][] seats=new int[x][y];
		int r=65;
		int c=1;
		System.out.print("  ");
		for(int k=0;k<y;k++){ 
			System.out.print(c+" ");
			c++;
		}
		System.out.println();
		for(int i=0;i<x;i++){
			System.out.print((char)r+" ");
			for(int j=0;j<y;j++){
				System.out.print(seats[i][j]+" ");
			}
			System.out.println();
			r++;
		}
	}
}
