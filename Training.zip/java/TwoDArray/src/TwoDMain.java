import java.util.*;
public class TwoDMain {
	public static void main(String[] args) {
		System.out.println("enter no.of rows and columns:");
		Scanner sc=new Scanner(System.in);
		int r=sc.nextInt();
		int c=sc.nextInt();
		int [][] seats=new int[3][4];
		System.out.println("Enter"+(r*c)+"values");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				seats[i][j]=sc.nextInt();
			}
		}
		System.out.println("Two D Array values are:");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				System.out.print(seats[i][j]+" ");
			}
			System.out.println();
		}
	}
}
