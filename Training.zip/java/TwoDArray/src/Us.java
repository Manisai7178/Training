	import java.io.BufferedReader;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.Collection;
	import java.io.*;

	class StoreData {
		String date;
		String product;
		String subproduct;
		String issue;
		String subissue;
		String company;
		String state;
		String zip;
		String submittedby;
		String datesent;
		String companyresponse;
		String timelyresponse;
		String customerdesp;
		String complntid;

		public StoreData(String date, String product, String subproduct, String issue, String subissue, String company,
				String state, String zip, String submittedby, String datesent, String companyresponse,
				String timelyresponse, String customerdesp, String complntid) {
			super();
			this.date = date;
			this.product = product;
			this.subproduct = subproduct;
			this.issue = issue;
			this.subissue = subissue;
			this.company = company;
			this.state = state;
			this.zip = zip;
			this.submittedby = submittedby;
			this.datesent = datesent;
			this.companyresponse = companyresponse;
			this.timelyresponse = timelyresponse;
			this.customerdesp = customerdesp;
			this.complntid = complntid;
		}

		public String getDate() {
			return date;
		}

		public void setDate(String date) {
			this.date = date;
		}

		public String getProduct() {
			return product;
		}

		public void setProduct(String product) {
			this.product = product;
		}

		public String getSubproduct() {
			return subproduct;
		}

		public void setSubproduct(String subproduct) {
			this.subproduct = subproduct;
		}

		public String getIssue() {
			return issue;
		}

		public void setIssue(String issue) {
			this.issue = issue;
		}

		public String getSubissue() {
			return subissue;
		}

		public void setSubissue(String subissue) {
			this.subissue = subissue;
		}

		public String getCompany() {
			return company;
		}

		public void setCompany(String company) {
			this.company = company;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getZip() {
			return zip;
		}

		public void setZip(String zip) {
			this.zip = zip;
		}

		public String getSubmittedby() {
			return submittedby;
		}

		public void setSubmittedby(String submittedby) {
			this.submittedby = submittedby;
		}

		public String getDatesent() {
			return datesent;
		}

		public void setDatesent(String datesent) {
			this.datesent = datesent;
		}

		public String getCompanyresponse() {
			return companyresponse;
		}

		public void setCompanyresponse(String companyresponse) {
			this.companyresponse = companyresponse;
		}

		public String getTimelyresponse() {
			return timelyresponse;
		}

		public void setTimelyresponse(String timelyresponse) {
			this.timelyresponse = timelyresponse;
		}

		public String getCustomerdesp() {
			return customerdesp;
		}

		public void setCustomerdesp(String customerdesp) {
			this.customerdesp = customerdesp;
		}

		public String getComplntid() {
			return complntid;
		}

		public void setComplntid(String complntid) {
			this.complntid = complntid;
		}

	}

	public class Us {

		public static void main(String[] args) {

			String csvFile = "D:\\complaints.csv";
			String line = "";
			String cvsSplitBy = ",";
			{

				try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
					ArrayList<StoreData> list = new ArrayList<StoreData>();
						while ((line = br.readLine()) != null) {
							String[] data = line.split(",");						
							list.add( new StoreData(data[0],data[1],data[2],data[3],data[4],data[5],data[6],data[7],data[8],data[9],data[10],data[11],data[12],data[13]));
							// System.out.println("Complaints [date= " +complaints[0] + " , issue=" + complaints[1] + "]");
						}
//						int i=1;
					for(int i=1;i<=list.size();i++){
							if(list.get(1).company=="Santander")
							{
						System.out.println(list.get(i).company);							
						System.out.println(list.get(i).companyresponse);
						System.out.println(list.get(i).complntid);
						System.out.println(list.get(i).customerdesp);
						System.out.println(list.get(i).date);
						System.out.println(list.get(i).datesent);
						System.out.println(list.get(1).issue);
						System.out.println(list.get(1).product);
						System.out.println(list.get(1).state);
						System.out.println(list.get(1).subissue);
						System.out.println(list.get(1).submittedby);
						System.out.println(list.get(1).subproduct);
						System.out.println(list.get(1).timelyresponse);
								}
								}
						
				} catch (IOException e) {
					e.printStackTrace();
				}
				
			}
		
			
			
		}
	}
