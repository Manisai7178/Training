interface AddInterface
{
	void add(int a,int b);
}
public class LambdaFuncDemo {

}
