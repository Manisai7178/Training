import java.util.*;
class Array{
	public static void main(String []args){
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of aarys:");
		int size=sc.nextInt();
		int[] marks=new int[size];
		System.out.println("Enter "+marks.length+" values:");
		for(int i=0;i<marks.length;i++){
			marks[i]=sc.nextInt();
		}
		System.out.println("Values in array are:");
		/*
		for(int i=0;i<marks.length;i++){
			System.out.println(marks[i]);
		}*/
		
		for(int m:marks){
			System.out.println(m);
		}
	}
}
