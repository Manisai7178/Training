package com.lti;

public class StringDemo
{

	public static void main(String a[])
	{
		byte[] b={65,66,67,97,98,99};
		String str=new String(b);
		System.out.println(str);
		
		String s="method";
		String str2=s.toUpperCase();
		System.out.println(str2);
		System.out.println(str2.toCharArray());
		
		
	}
}
