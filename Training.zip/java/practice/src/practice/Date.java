package practice;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.swing.text.DateFormatter;

public class Date 
{
	public static void main(String args[])
	{
		 LocalDate dt=LocalDate.now();
		 LocalTime t=LocalTime.now();
		 System.out.println(dt);
		 System.out.println(t);
		 
		 DateTimeFormatter dtf= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		 DateTimeFormatter dtf2= DateTimeFormatter.ofPattern("hh:mm:ss"); 
		 String d=dtf.format(dt);
		 String ti=dtf2.format(t);
		 System.out.println(d);
		 System.out.println(ti);
	}

}
