//sum of all the values in array
import java.util.*;
class SumArray{
	static void sum(int n,int a[]){
		int sum=0;
		for(int i=0;i<n;i++){
			sum=sum+a[i];
		}
		System.out.println(sum);
	}
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of elements:");
		int n=scan.nextInt();
		
		int arr[]=new int[n];
		for(int i=0;i<n;i++){
			arr[i]=scan.nextInt();
		}
		sum(n,arr);
	}
}