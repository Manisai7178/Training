package com.lti.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.lti.dao.EmpDao;
import com.lti.dao.EmpDaoimpl;
import com.lti.model.Employee;

public class MainPage {
	static int res = 0;

	public static void main(String a[]) throws SQLException {

		Scanner sc = new Scanner(System.in);
		while(true)
		{
		System.out.println("\t---------------Employee Management---------------");
		System.out.println("\n1. Add an Employee " + "\n2. Update an Employee " + "\n3. Delete an Employee "
				+ "\n4. Search an Employee " + "\n5. View All Employees " + "\n6. Exit");
		System.out.print("\nEnter you choice: ");
		int ch = sc.nextInt();
		Employee emp = new Employee();
		EmpDao dao = new EmpDaoimpl();
		
		switch (ch) {
		case 1:
			System.out.println("Enter name,salary and designation");
			String name = sc.next();
			double salary = sc.nextDouble();
			String des = sc.next();
			
			emp.setName(name);
			emp.setSalary(salary);
			emp.setDesignation(des);
			res = dao.addAnEmployee(emp);
			if (res > 0) {
				System.out.println("Employee Data Inserted");
				}
			else
			{
				System.out.println("Employee data not inserted");
			}

			break;
		case 2:System.out.println("Enter the psno");
				int psno = sc.nextInt();
				System.out.println("Enter name,salary and designation");
				name = sc.next();
				salary = sc.nextDouble();
				des = sc.next();
				emp = new Employee();
				emp.setName(name);
				emp.setSalary(salary);
				emp.setDesignation(des);
				emp.setPsno(psno);
				res = dao.updateAnEmployee(emp);
				if (res > 0) {
					System.out.println("Employee Data Updated");
					}
				else
				{
					System.out.println("Employee data not Updated");
				}

				
				break;
		case 3:System.out.println("Enter ps no");
				int psno1=sc.nextInt();
				emp.setPsno(psno1);
				res=dao.deleteAnEmployee(emp);
				if (res > 0) {
					System.out.println("Employee Data Deleted");
					}
				else
				{
					System.out.println("Employee data not Deleted");
				}
			break;
		case 4:System.out.println("Enter ps no");
				int psno2=sc.nextInt();
				Employee e =dao.searchAnEmployee(psno2);
				System.out.println(e.getPsno()+" "+e.getName()+" "+e.getDesignation()+" "+e.getSalary());
				break;
		case 5:List<Employee> eList = dao.displayEmployee();
		System.out.println("\n\t-------------Employee Table-------------\n"
		+ "\nPSNO	Name	Salary	Designation\n------------------------------------");
		eList.forEach(em->{
			System.out.println(em.getPsno()+"	"+em.getName()+"	"+em.getSalary()+"	"+em.getDesignation());
		});
		break;
		case 6:
			break;
		}
		}
		
	}

}
