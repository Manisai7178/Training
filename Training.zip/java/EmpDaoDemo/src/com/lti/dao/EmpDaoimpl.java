package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lti.model.Employee;

public class EmpDaoimpl implements EmpDao {


	final String URL="jdbc:oracle:thin:@localhost:1521:XE";
	final  String user="hr";
	final  String pass="hr";
	static Connection conn=null;
	static PreparedStatement ps=null;
	static String sql=null;
	
	
	
	public EmpDaoimpl() throws SQLException 
	{
		conn=DriverManager.getConnection(URL, user, pass);
	}
	@Override 
	public int addAnEmployee(Employee emp) throws SQLException 
	{
		
		
		sql="insert into employee values(psno.nextval,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, emp.getName());
		ps.setDouble(2, emp.getSalary());
		ps.setString(3, emp.getDesignation());
		int x=ps.executeUpdate();
		return x;
	}

	@Override
	public int updateAnEmployee(Employee emp) throws SQLException
	{
		sql="update employee set name=?,salary=?,designation=? where psno=?";
		ps=conn.prepareStatement(sql);
		ps.setString(1,emp.getName());
		ps.setDouble(2, emp.getSalary());
		ps.setString(3, emp.getDesignation());
		ps.setInt(4, emp.getPsno());
		int i=ps.executeUpdate();
		return i;
		

	}

	@Override
	public int deleteAnEmployee(Employee emp) throws SQLException 
	{
		sql="delete from employee where psno=?";
		ps=conn.prepareStatement(sql);
		ps.setInt(1, emp.getPsno());
		int i=ps.executeUpdate();
		return i;
		
		
		

	}

	@Override
	public Employee searchAnEmployee(int psNo) throws SQLException {
		Statement st=conn.createStatement();
		Employee emp = null;
		ResultSet rs=st.executeQuery("select * from employee where psno="+psNo);
		while(rs.next()){
			emp = new Employee(rs.getInt(1),rs.getString(2), rs.getDouble(3), rs.getString(4));
					
		}
		return emp;
	}

	@Override
	public List<Employee> displayEmployee() throws SQLException {
		Statement st = conn.createStatement();
		List<Employee> eList = new ArrayList<>();
		ResultSet rs = st.executeQuery("select * from Employee");
		
		while(rs.next()){
		eList.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4)));
		}
		
	
		
		return eList;
	}

}
