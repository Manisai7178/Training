package com.lti.dao;

import java.sql.SQLException;
import java.util.List;

import com.lti.model.Employee;

public interface EmpDao 
{
	int addAnEmployee(Employee emp) throws SQLException ;
	int updateAnEmployee(Employee emp) throws SQLException;
	int deleteAnEmployee(Employee emp) throws SQLException;
	Employee searchAnEmployee(int psno) throws SQLException;
	public List<Employee> displayEmployee() throws SQLException;
	
	
	
}
