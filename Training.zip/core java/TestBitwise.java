class TestBitwise{
	public static void main(String []args){
		int a=67;
		int b=79;

		System.out.println(a&b);
		int x=10;
		System.out.println(x>>2);	
	}
}



















