
class ArrayDemo{
	public static void main(String []args){

		int []arr={10,20,30,40,50,60};

		for(int i=0;i<6;i++){
			System.out.println(arr[i]);
		}
		
		int []num;

		num=arr;

		for(int i=0;i<6;i++){
			System.out.println(num[i]);
		}
		
				
	}
}