import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;

@WebServlet("/register.do")
public class RegServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	static String url="jdbc:oracle:thin:@//localhost:1521/XE";
	static String un="hr";
	static String pw="hr";
    Connection con=null;
    public void init(){
    	
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter();
        String cid = request.getParameter("cid");
        String cname = request.getParameter("cname");
        String coursetype = request.getParameter("coursetype");
        String city = request.getParameter("city");
        String fees = request.getParameter("fees");
        String pincode = request.getParameter("pincode");
        try {
        	Class.forName("oracle.jdbc.driver.OracleDriver");
          con = DriverManager.getConnection(url,un,pw);
            System.out.println("Connection establised");
            PreparedStatement ps = con.prepareStatement("insert into college values(?,?,?,?,?,?)");
            ps.setString(1, cid);
            ps.setString(2, cname);
            ps.setString(3, coursetype);
            ps.setString(4, city);
            ps.setString(5, fees);
            ps.setString(6, pincode);
            
            int i = ps.executeUpdate();
            
            if(i > 0) {
                out.println("You are sucessfully registered");
            }
        
        }
        catch(Exception se) {
            se.printStackTrace();
        }
	
    }
}