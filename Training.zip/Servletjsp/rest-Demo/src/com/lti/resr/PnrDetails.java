package com.lti.resr;

import java.time.LocalDate;
import java.util.List;

public class PnrDetails 
{
	private long pnrNo;
	private int trainNo;
	private LocalDate travelDate;
	private List<Passenger> passengers;
	
	public LocalDate getTravelDate() {
		return travelDate;
	}
	public void setTravelDate(LocalDate travelDate) {
		this.travelDate = travelDate;
	}
	public long getPnrNo() {
		return pnrNo;
	}
	public void setPnrNo(long pnrNo) {
		this.pnrNo = pnrNo;
	}
	public int getTrainNo() {
		return trainNo;
	}
	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}
	public List<Passenger> getPassengers() {
		return passengers;
	}
	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}
	public PnrDetails(long pnrNo, int trainNo, LocalDate travelDate, List<Passenger> passengers) {
		super();
		this.pnrNo = pnrNo;
		this.trainNo = trainNo;
		this.travelDate = travelDate;
		this.passengers = passengers;
	}
	public PnrDetails() {
		super();
	}
	
	
	
}
