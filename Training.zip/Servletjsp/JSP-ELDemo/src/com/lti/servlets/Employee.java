package com.lti.servlets;

public class Employee 
{
	int empId;
	String empName;
	double sal;
	Vehicle v;
	public Employee(int empId, String empName, double sal, Vehicle v) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.sal = sal;
		this.v = v;
	}
	public Employee() {
		super();
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public void setV(Vehicle v) {
		this.v = v;
	}
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public double getSal() {
		return this.sal;
	}
	public Vehicle getV() {
		return v;
	}
	
}
