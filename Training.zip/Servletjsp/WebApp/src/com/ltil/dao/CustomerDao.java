package com.ltil.dao;

import java.sql.SQLException;
import java.util.List;

import com.ltil.bean.Customer;

public interface CustomerDao 
{
	public List<Customer> getAllCustomers() throws SQLException; 
}
