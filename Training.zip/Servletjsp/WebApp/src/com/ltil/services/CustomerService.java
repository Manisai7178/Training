package com.ltil.services;

import java.sql.SQLException;
import java.util.List;

import com.ltil.bean.Customer;
import com.ltil.dao.CustomerDao;

public interface CustomerService 
{
	Customer getCustomerDetails(int customerNo);
	public List<Customer> getAllCustomers() throws SQLException;

}
