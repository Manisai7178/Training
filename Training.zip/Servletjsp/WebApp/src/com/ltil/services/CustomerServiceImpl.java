package com.ltil.services;

import java.sql.SQLException;
import java.util.List;

import com.ltil.bean.Customer;
import com.ltil.dao.CustomerDao;
import com.ltil.dao.CustomerDaoImpl;

public class CustomerServiceImpl implements CustomerService
{
CustomerDao dao;
	
	public CustomerServiceImpl() throws SQLException 
	{
		dao=  new CustomerDaoImpl();
	}
	public List<Customer> getAllCustomers() throws SQLException 
	{
	List<Customer> myList;
	
		myList = dao.getAllCustomers();
		return myList;
				
	}
	@Override
	public Customer getCustomerDetails(int customerNo) {
		// TODO Auto-generated method stub
		return null;
	}
}
