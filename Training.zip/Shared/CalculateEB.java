import java.util.*;

class CalculateEB{


static void calculate(int GST, int unit)
{
  int amountPayable;
   if(GST != 18)
 {
	if(unit <= 200)
    {
      amountPayable = 0;
      System.out.println("Total Unit: "+ unit);
      System.out.println("GST:"+GST+"%");
      System.out.println("Amount Payable: "+ amountPayable);
    }
 
  else 
    {
      amountPayable = (unit * 5) + (unit * 5)*GST/100;
      System.out.println("Total Unit: "+ unit);
      System.out.println("GST:"+GST+"%");
      System.out.println("Amount Payable: "+ amountPayable);
    }
    
 } 
    else
    {
      amountPayable = amountPayable = (unit * 10) + (unit * 10)*GST/100;
      System.out.println("Total Unit: "+ unit);
      System.out.println("GST:"+GST+"%");
      System.out.println("Amount Payable: "+ amountPayable);  
    }
}
  
 static void checkCategory(String category,int unit){
        switch(category)
{
            case "B": calculate(18,unit);
                      break;
            case "M": calculate(9,unit);
 		      break;
 	    case "S": calculate(5,unit);
 		      break;
	    default: System.out.println("Not valid");
         }

   }

  public static void main(String args[]){
  
 Scanner scan = new Scanner(System.in);
  int unit;
  String category;
  int GST;

  System.out.println("Enter unit");
  unit = scan.nextInt();
  System.out.println("Enter category");
  category = scan.next();


  checkCategory(category, unit);  



  }
}