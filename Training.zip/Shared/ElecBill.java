//WAP to calculate the total electricity bill to be paid. per unit price = 10 + 18% gst(business), 5 + household -> singles 5%, married 9%
//<200 household free business not free

import java.util.Scanner;
class ElecBill{
	static void calc(int un, char liv){
	double amount;
	Scanner sc = new Scanner(System.in);
	
	switch(liv){
		case 'b':	amount = un*10*1.18;
				System.out.println("Total Unit: "+ un);
				System.out.println("GST: 18%");
				System.out.println("Amount Payable: "+ amount);
				break;
		case 'h':	if(un>200){	
					System.out.print("Single or married? (s/m): ");
					char c = sc.next().charAt(0);
					switch(c){
					case 's':	amount = un * 5 * 1.05;
							System.out.println("Total Unit: "+ un);
							System.out.println("GST: 5%");
							System.out.println("Amount Payable: "+ amount);
							break;
					case 'm':	amount = un * 5 * 1.09;
							System.out.println("Total Unit: "+ un);
							System.out.println("GST: 9%");
							System.out.println("Amount Payable: "+ amount);
							break;
					}
				}
				else
						System.out.println("Total Unit: "+ un);
						System.out.println("GST: 0%");
						System.out.println("Amount Payable: 0");
			
		}

	}

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Unit: ");
		int un = sc.nextInt();
		System.out.print("Enter Living type(b/h): ");
		char liv = sc.next().charAt(0);
		calc(un, liv);
	}
}