
import java.util.*;
class Even_Sum2
{

   public static void main(String args[])
   {
     int sum=0,n;
     Scanner s = new Scanner(System.in);
     do
     {
     System.out.println("Enter the number");
     n=s.nextInt();
     if(n>100)
         break;
     if(n%2==0)
         sum = sum+n;
     else
         continue;
     System.out.println("Sum ="+sum);
     }while(true);
     
   }
}