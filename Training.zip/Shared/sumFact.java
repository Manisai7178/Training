import java.util.Scanner;

public class sumFact{

	public static void main(String[] args)

	{
			Scanner sc = new Scanner(System.in);
			int num = sc.nextInt();
				
			double square[] = new double[num];
			double fact[] = new double[num];
			square[0] = 0.0;
			fact[0] = 1.0;
			
			
			for(int i=1;i<num;i++)
			{
				fact[i] = fact[i-1]*(i);
				square[i] = i*i;	
			}

			double sum = 0.0;
			for(int i=0;i<num;i++)
			{
				sum += square[i]/fact[i];
			}
			
			System.out.println(sum);
			
	}
}