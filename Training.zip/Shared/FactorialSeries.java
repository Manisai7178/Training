import java.util.*;
class FactorialSeries
{
    static int fact(int a){

    if(a>=1)  
     return a*fact(a-1);
    else 
     return 1;
    }
   public static void main(String args[]){
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter a number:");
     int num=sc.nextInt();

     double sum=0.0;
     for(int i=1;i<=num;i++)
     	sum=sum+((i*i)/(double)fact(i));
    
     System.out.println("Sum is:"+sum);
  }
}