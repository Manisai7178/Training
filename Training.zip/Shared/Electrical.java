
import java.util.Scanner;
class Electrical{
	static void BillPaid(int unit,String type){
		int totalUnit;
		double gst;
		switch(type){
			case "household":Scanner scan=new Scanner(System.in);
					System.out.println("Enter the (single/married)");
					String sm=scan.next();
				if(unit>200){
					totalUnit=unit*5;
					if(sm=="single"){
						gst=totalUnit*0.05;
						System.out.println("Total unit:"+totalUnit);
						System.out.println("GST 5%:"+gst);
						System.out.println("Amount Payable:"+(totalUnit+gst));
				
					}
					else{
						gst=totalUnit*0.09;
						System.out.println("Total unit:"+totalUnit);
						System.out.println("GST 9%:"+gst);
						System.out.println("Amount Payable:"+(totalUnit+gst));
					}	
				}
				else{
					System.out.println("Generate the bill");
				}
				break;

			case "business":totalUnit=unit*10;
					gst=totalUnit*0.18;
					System.out.println("Total unit:"+totalUnit);
					System.out.println("GST 18%:"+gst);
					System.out.println("Amount Payable:"+(totalUnit+gst));
					break;
		}
	}
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Units");
		int unit=scan.nextInt();
		System.out.println("Enter the Type(household/business)");
		String type=scan.next();
		
		BillPaid(unit,type);
	}
}