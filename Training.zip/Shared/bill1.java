import java.util.Scanner;

public class Bill1{
	
	double[] household(int units, String status)
	{
		double bill[] = new double[2];
		if(units <= 200)
		{
			bill[0] = 0;
			bill[1] = 0;
		}
		else
		{
			bill[0] = 5.0*units;
			
			if(status.equals("married"))
			{
				bill[1] = bill[0]*0.12;
			}
			else{
				bill[1] = bill[0]*0.05;
			}
			
		}
		return bill;
	}
	
	double[] business(int units)
	{
		double bill[] = new double[2];
		
		bill[0] = 10.0*units;
		
		bill[1] = bill[0]*0.18;	
		
		return bill;
	}
	
	public static void main(String[] args)
	{
		int units = 0;
		String type = "";
		String status = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Units Consumed: ");
		units = sc.nextInt();
		

		Bill1 bill = new Bill1();
		System.out.println("Business or Household: ");
		type = sc.next();
		
		if(type.equals("household"))
		{
			System.out.println("Single or married ");
			status = sc.next();
		}
		
		double values[] = {0.0,0.0};
		
		switch(type)
		{
			case "business" : values = bill.business(units);
							  break;
			case "household": values = bill.household(units,status);
							  break;
			default : System.out.println("Enter valid Information");					
		}
		System.out.println("Total Units : " + units);
		System.out.println("GST: " + values[1]);
		System.out.println("Amount payable : " + (values[0] + values[1]));
	}
}