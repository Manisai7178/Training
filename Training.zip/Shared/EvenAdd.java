import java.util.Scanner;

class EvenAdd {

	public static void main(String args[])
	{
  
   
		int sum = 0;
		int value;
		Scanner scan = new Scanner(System.in);

	do
	{
		System.out.println("Enter a value:");
 		value = scan.nextInt();
		if(value < 100)
 		{
  			if(value%2 == 0)
   			{
    				sum+=value;
    				System.out.println("The sum is"+sum);   
  			 } 
 			 else 
   			{
    				System.out.println("The sum is"+sum);
  			 }

 		}
		 else 
 		{
				break;
		 }
	} while(true);


  	}

}