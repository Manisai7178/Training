import java.util.*;
class Sequence{
	static int fact(int x)
	{
	 int f=1;
	  for(int i=x;i>1;i--)
		{
		f=f*i;
		}
	return f;
	}
	public static void main(String[]args){
	
	Scanner sc=new Scanner(System.in);
	int value=sc.nextInt();
	int sum=0;
	for(int i=1;i<=value;i++)
		{
		sum+=((i*i)/fact(i));
		}
	System.out.println(sum);
   }
}