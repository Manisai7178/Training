import java.util.*;
class SquareFactorial{
	static double fact(double x)
	{
	 double f=1;
	  for(double i=x;i>1;i--)
		{
		f=f*i;
		}
	return f;
	}
	

	static double pow(double x)
	{
	 double p;
         p = x*x;
	 return p;
        }


	public static void main(String[]args){
	
	Scanner sc=new Scanner(System.in);
	int value=sc.nextInt();
	double sum=0;
	for(double i=1;i<=value;i++)
		{
		sum+=(pow(i)/fact(i));
		}
	System.out.println(sum);
   }
}