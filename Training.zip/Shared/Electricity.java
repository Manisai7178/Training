//to calculate the total electricity bill

import java.util.*;
class Bill
{
	Scanner sc = new Scanner(System.in);
	public void calc(char ch, double u)
	{	
		double TU, GST, TA;
		switch(ch)

		{
			case 'H':
				System.out.println("For single press s and For married press m");
				char ch1 = sc.next().charAt(0);
				if(ch1 == 's')
				{
					TU = u * 5;
					GST = TU * 0.05;
					TA = TU + GST;
					System.out.println("Total = " + TU);
					System.out.println("GST = " + GST);
					System.out.println("paid amount =" + TA);
				}
				else if(ch1 == 'm')
				{
					 TU = u * 5;
					 GST = TU * 0.09;
					 TA = TU + GST;
					System.out.println("Total = " + TU);
					System.out.println("GST = " + GST);
					System.out.println("paid amount =" + TA);
				}
				/*else{
					System.out.println("Invalid Input");
				}*/
				break;

			case 'B':
				
					TU = u * 5;
					GST = TU * 0.18;
					TA = TU + GST;
					System.out.println("Total = " + TU);
					System.out.println("GST = " + GST);
					System.out.println("paid amount =" + TA);
				break;
		}
	}

}

class Electricity
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in); 
		Bill b = new Bill();
		System.out.println("Enter H for household, Enter B for business");
		char ch = sc.next().charAt(0);
		System.out.println("Enter the unit");
		double u = sc.nextDouble();
		b.calc(ch,u);		
	}


}