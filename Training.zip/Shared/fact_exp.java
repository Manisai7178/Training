N// Find factorial sum expression

import java.util.*;
class fact_exp
{
     static double factorial(int a)
     {
          double f=1.0;
          for(int i=1;i<=a;i++)
          {
               f=f*i;
           }
         return f;
     }
     public static void main(String args[])
     {
           int n;
           Scanner s = new Scanner(System.in);
           System.out.println("Enter the limit");
           n=s.nextInt();
     
           double sum=0.0;
           for(int i=1;i<=n;i++)
           {
                sum = sum+((i*i)/factorial(i));
            }
            System.out.println("The sum of expression is "+sum);
       }
}
