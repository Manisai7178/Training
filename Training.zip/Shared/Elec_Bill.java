//WAP to calculate thetotal electricity bill to be paid

import java.util.*;
class Elec_Bill
{
	static void Cal_Bill()
	{
            Scanner s=new Scanner(System.in);
		System.out.println("Enter the units consumed");
	        double unit_consumed=s.nextDouble();
            System.out.println("Enter your choice");
            System.out.println("Enter H for Household and B for Business");
            char ch= s.next().charAt(0);

	    
	   double tot_unit=0.0;
	    double gst=0.0, tot_amt=0.0;

             switch(ch)
        	{

			case 'H':
 			if(unit_consumed>200)
			  {
		
                        	System.out.println("Enter choices for Single or Married");
				System.out.println("Enter S for Single or M for Married");
				char ch1=s.next().charAt(0);

				if(ch1=='S')
			        {
					tot_unit = (double)5.0 * unit_consumed;
					gst = tot_unit * 0.05;
					tot_amt = tot_unit + gst;
					System.out.println("Total unit : "+tot_unit);
	                                System.out.println("GST 5%: "+gst);
                                        System.out.println("Amount Payable : "+tot_amt);

				}
					
				if(ch1=='M')
				{
					tot_unit = (double)5.0 * unit_consumed;
					gst = tot_unit * 0.05;
					tot_amt = tot_unit + gst;
					System.out.println("Total unit : "+tot_unit);
	                                System.out.println("GST 9%: "+gst);
                                        System.out.println("Amount Payable : "+tot_amt);

				}
				
			}
			else
                     	{    System.out.println("FREE");
			}
			
              		break;
			case 'B':

				        tot_unit = (double)10.0 * unit_consumed;
					gst = tot_unit * 0.18;
					tot_amt = tot_unit + gst;
					System.out.println("Total unit : "+tot_unit);
	    			        System.out.println("GST 18%: "+gst);
                                        System.out.println("Amount Payable : "+tot_amt);

                         break;
			default:
					System.out.println("Invalid choices");
			break;
		     
		
             
	}

        }
 	public static void main(String args[])
 	{
		
		
		Cal_Bill();
	
         }
}