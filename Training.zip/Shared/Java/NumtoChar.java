//WAP to print a number of 4 digits in words
import java.util.Scanner;
class NumtoChar{
	static void convert ( int a){
	int count = 1;
	int th = a/1000;
	a = a%1000;
	int hun = a/100;
	a = a%100;
	int ten = a/10;
	a = a%10;

	if(th>0){

	if(th == 1)
		System.out.print(" One Thousand ");
	if(th == 2)
		System.out.print(" Two Thousand ");
	if(th == 3)
		System.out.print(" Three Thousand ");
	if(th == 4)
		System.out.print(" Four Thousand ");
	if(th == 5)
		System.out.print(" Five Thousand ");
	if(th == 6)
		System.out.print(" Six Thousand ");
	if(th == 7)
		System.out.print(" SevenThousand ");
	if(th == 8)
		System.out.print(" Eight Thousand ");
	if(th == 9)
		System.out.print(" Nine Thousand ");

	}
	if(hun>0){

	if(hun == 1)
		System.out.print(" One Hundred ");
	if(hun == 2)
		System.out.print(" Two Hundred ");
	if(hun == 3)
		System.out.print(" Three Hundred ");
	if(hun == 4)
		System.out.print(" Four Hundred ");
	if(hun == 5)
		System.out.print(" Five Hundred ");
	if(hun == 6)
		System.out.print(" Six Hundred ");
	if(hun == 7)
		System.out.print(" Seven Hundred ");
	if(hun == 8)
		System.out.print(" Eight Hundred ");
	if(hun == 9)
		System.out.print(" Nine Hundred ");
	}

	if(ten>0){

	if(ten == 1){
	
	if(a == 1){
		System.out.print(" Eleven ");
		return;
	}
	if(a == 2){
		System.out.print(" Twelve ");
		return;	
	}
	if(a == 3){
		System.out.print(" Thirteen ");
		return;
	}
	if(a == 4){
		System.out.print(" Fourteen ");
		return;
	}
	if(a == 5){
		System.out.print(" Fifteen ");
		return;
	}
	if(a == 6){
		System.out.print(" Sixteen ");
		return;
	}
	if(a == 7){
		System.out.print(" Seventeen ");
		return;
	}
	if(a == 8){
		System.out.print(" Eighteen ");
		return;
	}
	if(a == 9){
		System.out.print(" Nineteen ");
		return;
	}
	if(a == 0){
		System.out.print(" Ten ");
		return;
	}
	}


	if(ten == 2)
		System.out.print(" Twenty ");
	if(ten == 3)
		System.out.print(" Thirty ");
	if(ten == 4)
		System.out.print(" Fourty ");
	if(ten == 5)
		System.out.print(" Fifty");
	if(ten == 6)
		System.out.print(" Sixty ");
	if(ten == 7)
		System.out.print(" Seventy");
	if(ten == 8)
		System.out.print(" Eighty ");
	if(ten == 9)
		System.out.print(" Ninety ");
	}

	if(a>0){

	if(a == 1){
		System.out.print(" One ");
	}
	if(a == 2){
		System.out.print(" Two ");
	}
	if(a == 3){
		System.out.print(" Three ");
	}
	if(a == 4){
		System.out.print(" Four ");
	}
	if(a == 5){
		System.out.print(" Five ");
	}
	if(a == 6){
		System.out.print(" Six ");
	}
	if(a == 7){
		System.out.print(" Seven ");
	}
	if(a == 8){
		System.out.print(" Eight ");
	}
	if(a == 9){
		System.out.print(" Nine ");
	}
	}
	}
	

		
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int s = sc.nextInt();
		convert(s);
	}
}