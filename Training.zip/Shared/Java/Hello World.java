class Hello World
{
	public static void man(String args[]){
		System.out.print('Hello World');
	}
}