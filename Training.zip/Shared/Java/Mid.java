class Mid{
	void check ( int a, int b, int c){

		if( (a<b && a>c) || (a>b && a<c) ){
			System.out.print(a);
			return;
		}
		else if( (b<a && b>c) || (b>a && b<c) ){
			System.out.print(b);
			return;
		}
		else if( (c<a && c>b) || (c>a && c<b) ){
			System.out.print(c);
			return;
		}
		else if( a==b && a==c ){
			System.out.print("They are same!");
			return;
		}
		else{
			System.out.print("Cannot find mid!");
			return;
		}
	}
	public static void main(String[] args){
		int a = 10;
		int b = 20;
		int c = 30;
		Mid m = new Mid();
		m.check(a,b,c);
	}
}