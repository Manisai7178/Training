//Sum of Series
import java.util.Scanner;
class FactSeries{
	static int fact(int n){
		if(n == 1 || n==0)
			return 1;
		else
			return n*fact(n-1);
	}

	public static void main(String [] args){
		float sum = 0.0f;
		int n;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();

		for(int i = 1; i<=n; i++){
			sum += (float)(i*i)/fact(i);
		}
		System.out.println("The sum of the series is: "+sum);
		
	}
}