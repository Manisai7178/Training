import java.util.Scanner;
class ArrayDemo{
	public static void main(String[] args){
		int[] arr = new int[5];
		Scanner sc = new Scanner(System.in);

		for(int i = 0; i<5; i++)
			arr[i] = sc.nextInt();	
		System.out.print("-------------------------\n");

		int[] num = arr;
		for(int i = 0; i<5; i++)
			System.out.print(num[i]+" ");

		System.out.print("\n");
	}
}