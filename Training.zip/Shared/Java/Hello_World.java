class Mid
{
	public static void main(String[] args){
		int a[3];
		Scanner sc = new Scanner();
	for(int i = 0; i<3; i++){
System.out.print("Enter "+(i+1)+ ": ");
a[i] = sc.nextInt();
}
	}
}