//WAP to print a number of 4 digits in words
import java.util.Scanner;
class NumtoChar2{
	static void convert ( int a){
	int count = 1;
	int th = a/1000;
	a = a%1000;
	int hun = a/100;
	a = a%100;
	int ten = a/10;
	a = a%10;
	String[] ones = {"One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};
	String[] tens = { "Eleven", "Twelve", "Thirteen","Fourteen","Fifteen ", "Sixteen", "Seventeen", "Eighteen", "Nineteen"};
	String[] tens2 = {"Twenty ","Thirty ", "Forty ", "Fifty ","Sixty ","Seventy ","Eighty ","Ninety "};
	
	if(th>0)
		System.out.print(ones[th-1] + " Thousand ");

	if(hun>0)
		System.out.print(ones[hun-1] + " Hundred ");

	if(ten>0){

		if(ten == 1){
			if(a==0)
				System.out.print("Ten");
			else
				System.out.print(tens[a-1]);
			return;
		}
	else
		System.out.print(tens2[ten-1]);
	}

	if(a>0){

		System.out.print(ones[a-1]);
	}
	
	}
		
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int s = sc.nextInt();
		convert(s);
	}
}