//Enter number even sum
import java.util.Scanner;
class AddLoop{
	public static void main(String [] args){
		int sum = 0, n;
		Scanner sc = new Scanner(System.in);
		while(true){
			System.out.print("Enter number(>100 to exit): "); 
			n = sc.nextInt();
			if(n>100)
				break;
			
			if(n%2 == 0)
				sum+= n;		
			System.out.println("The sum of even numbers is: "+sum);
		}
		System.out.println("The final sum of even numbers is: "+sum);
		
	}
}