import java.util.*;
class P4
{
static void sum1()
{
Scanner s=new Scanner(System.in);
int sum=0;
while(true)
{
System.out.println("enter the number");
int a=s.nextInt();
if(a>100)
{
break;
}
if(a%2==0)
{
sum=sum+a;
}
}
System.out.println(sum);
}
public static void main(String args[])
{
sum1();
}
}