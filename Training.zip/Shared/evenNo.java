import java.util.Scanner;

public class evenNo{

	public static void main(String[] args)

	{
			Scanner sc = new Scanner(System.in);
			int num;
			int sum = 0;
				
			do{
				System.out.println("Enter numbers: ");
				num = sc.nextInt();
				
				if(num%2 != 0)
				{
					break;
				}
				else
				{
					sum += num;
					continue;
				}
			
			}while(num < 101);
			
			if(num >=101 && num%2 == 0)
			{
				sum -= num;
			}
			
			System.out.println("Sum is " + sum);
			
	}
}