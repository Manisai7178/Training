import java.util.Scanner;
class fact_num
{
static int fact(int number)
	{ 
	if(number==0||number==1)
	return 1;
else return(number*fact(number-1));
	}

public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		int number;
                System.out.println("enter num");
		number=scan.nextInt();
		int r=fact(number);
		System.out.println("fact"+r);
		
	}
}