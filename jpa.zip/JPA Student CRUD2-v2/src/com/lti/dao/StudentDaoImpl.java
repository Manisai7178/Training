package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.lti.model.Student;
import com.lti.util.JpaUtil;

public class StudentDaoImpl implements StudentDao {
	private EntityManager entityManager;
	
	public StudentDaoImpl() {
		entityManager = JpaUtil.getEntityManager();
	}

	@Override
	public int insertStudent(Student student) {
		entityManager.persist(student);
		return 1;
	}

	@Override
	public int deleteStudent(int id) {
//		Student stu = entityManager.find(Student.class, id);
//		entityManager.remove(stu);
		String jpql = "Delete from Student where rollno = :id";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("id", id);
		return query.executeUpdate();
	}

	@Override
	public Student readStudent(int id) {
		return entityManager.find(Student.class, id);
	}

	
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void rollbackTransaction() {
		entityManager.getTransaction().rollback();
		
	}

	@Override
	public int updateStudent(Student student) {
		entityManager.merge(student);
		return 1;
	}

	
	@Override
	public List<Student> viewAllStudents() {
		
		String jpql = "Select s from Student s";
		//Query query = entityManager.createQuery(jpql);
		TypedQuery<Student> query = entityManager.createQuery(jpql,Student.class);
		List<Student> list = query.getResultList();
		return list;
	}

}
