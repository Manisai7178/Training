package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student {
	@Id
	@Column(name="rollno")
	private int rollNo;
	
	@Column(name="name")
	private String name;
	
	@Column(name="score")
	private double score;
	
	public Student() {
	}
	@Override
	public String toString() {
		return "Student rollNo=" + rollNo + ", name=" + name + ", score=" + score ;
	}
	public Student(int rollNo, String name, double score) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.score = score;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollno(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	} 

}
