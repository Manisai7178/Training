package com.lti.ui;
import java.util.Scanner;

import com.lti.model.Student;
import com.lti.service.StudentService;
import com.lti.service.StudentServiceImpl;

public class Main {
	

	public static void main(String[] args) {
		StudentService service = new StudentServiceImpl();
		Student student;
		Scanner sc = new Scanner(System.in);
		
		int id, choice, result;
		String name;
		double score;
		Student stu = null;
		
		while(true){
			System.out.println("\n1. Insert \n2. Search \n3. Remove \n4. Update \n5. Exit");
			System.out.print("\nEnter Choice: ");
			choice = sc.nextInt();
			
			switch(choice){
				case 1:
					System.out.print("Enter ID: ");
					id = sc.nextInt();
					
					System.out.print("Enter Name: ");
					name = sc.next();
					
					System.out.print("Enter Score: ");
					score = sc.nextDouble();
					
					student = new Student(id, name, score);
					if(service.addStudent(student))
						System.out.println("Student "+id+ " is added.");
					break;
				
				case 2:
					System.out.print("\nEnter Roll number: ");
					id = sc.nextInt();
					stu = service.findStudentByRollNumber(id);
					System.out.println("\nName: "+stu.getName()+"\nScore: "+stu.getScore());
					
					break;
				
				case 3:
					System.out.print("\nEnter Roll number to delete: ");
					id = sc.nextInt();
					result = service.removeStudent(id);
					if (result == 1)
						System.out.println("Student "+id+ " is deleted.");
					else
						System.out.println("Could not delete");
					break;
					
				case 4:
					System.out.print("\nEnter Roll number: ");
					id = sc.nextInt();
					stu = service.findStudentByRollNumber(id);
					
					System.out.print("\nWhat to change? \n1. Name \n2. Score \nEnter choice: ");
					choice = sc.nextInt();
					switch(choice){
					case 1:
						System.out.print("\nEnter new name: ");
						name = sc.next();
						stu.setName(name);
						
						result = service.updateStudent(stu);
						if (result == 1)
							System.out.println("\nStudent "+id+ " updated with name: "+name);
						else
							System.out.println("\nCould not update");
						break;
					case 2:
						System.out.print("\nEnter new score: ");
						score = sc.nextDouble();
						stu.setScore(score);
						
						result = service.updateStudent(stu);
						if (result == 1)
							System.out.println("\nStudent "+id+ " updated with score: "+score);
						else
							System.out.println("\nCould not update");
						break;
					default:
						System.out.println("Invalid Choice");
					}
					
					break;
					
				case 5:
					sc.close();
					System.exit(0);
					
				default:
					System.out.println("Invalid Choice");
		}
		}
		
	}
}
