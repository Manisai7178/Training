package com.lti.dao;

import com.lti.model.Student;

public interface StudentDao {
	public int insertStudent(Student student);
	public Student readStudent(int id);
	public int deleteStudent(int id);
	
	public void beginTransaction();
	public void commitTransaction();
	public void rollbackTransaction();
	public int updateStudent(Student student);
}
