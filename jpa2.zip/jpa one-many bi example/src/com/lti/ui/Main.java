package com.lti.ui;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.lti.model.Department;
import com.lti.model.Employee;



public class Main {

	public static void main(String[] args) 
	{

		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA_PU");
		EntityManager entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		Department dept1=new Department(10,"Development");
		Employee emp1=new Employee(01,"Akhila",7500);
		Employee emp2=new Employee(02,"Anirudh",8500);
		Employee emp3=new Employee(03,"Anuhya",9500);
		Employee emp4=new Employee(04,"Aravind",10500);
		Employee emp5=new Employee(05,"Bhargavi",9500);
		Set<Employee> emps=new HashSet<>();
		emps.add(emp1);
		emps.add(emp2);
		emps.add(emp3);
		emps.add(emp4);
		emps.add(emp5);
		dept1.setEmployees(emps);
		emp1.setDepartment(dept1);
		emp2.setDepartment(dept1);
		emp3.setDepartment(dept1);
		emp4.setDepartment(dept1);
		emp5.setDepartment(dept1);
		
		Department dept2=new Department(20,"HR");
		Employee emp6=new Employee(06,"Bhavani",7500);
		Employee emp7=new Employee(07,"Jyothi",8500);
		Employee emp8=new Employee(8,"Keerthi",9500);
		Employee emp9=new Employee(9,"Manisha",10500);
		Employee emp10=new Employee(10,"Mounika",9500);
		Set<Employee> emps2=new HashSet<>();
		emps2.add(emp6);
		emps2.add(emp7);
		emps2.add(emp8);
		emps2.add(emp9);
		emps2.add(emp10);
		dept2.setEmployees(emps2);
		emp6.setDepartment(dept2);
		emp7.setDepartment(dept2);
		emp8.setDepartment(dept2);
		emp9.setDepartment(dept2);
		emp10.setDepartment(dept2);
		
		entityManager.persist(dept1);
		entityManager.persist(dept2);
		
		
		
		
		entityManager.getTransaction().commit();
		entityManager.close();
		factory.close();
		 
		 
		 
	}

}

