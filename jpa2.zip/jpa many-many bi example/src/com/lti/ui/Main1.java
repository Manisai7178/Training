package com.lti.ui;


import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import com.lti.model.Authors;
import com.lti.model.Books;

public class Main1 
{
	private static EntityManagerFactory factory;
	private static EntityManager entityManager;	

public static void loadData()
{
	Books b1=new Books(123456789,"java volume-1",580.50);
	Books b2=new Books(987654321,"Cricket Memories",400);
	Authors a1=new Authors(1,"Cay Horstman");
	Authors a2=new Authors(2,"Martin Guptil");
	
	List<Authors> list1 = new ArrayList<>();
	list1.add(a1);
	list1.add(a2);
	b1.setAuthors(list1);
	List<Authors> list2 = new ArrayList<>();
	list1.add(a1);
	list1.add(a2);
	b2.setAuthors(list2);
	
	entityManager.getTransaction().begin();
	entityManager.persist(b1);
	entityManager.persist(b2);
	
	entityManager.getTransaction().commit();
	
	
	

	
}
public static void main(String args[])
{
	loadData();
	String jpql="select b from Books b";
	TypedQuery<Books> tquery = entityManager.createQuery(jpql,Books.class);
	List<Books> result = tquery.getResultList();
	for (Books b1:result)
	{
		System.out.println("Book Isbn:"+b1.getISBN());
		System.out.println("BookName :"+b1.getName());
		System.out.println("Book Price"+b1.getPrice());
		List<Authors> authors=b1.getAuthors();
		for (Authors a:authors)
		{
			System.out.println("Author id:"+a.getID());
			//System.out.println("Author Name:"a.getName());
		}
		System.out.println("-------------------------------------------------------");
	
		
	}
}
}
