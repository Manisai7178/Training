package com.lti.ui;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.lti.model.Authors;
import com.lti.model.Books;






public class Main {

	public static void main(String[] args) {

		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA_PU");
		EntityManager entityManager=factory.createEntityManager();
		
		entityManager.getTransaction().begin();
		Books b1=new Books();
		b1.setISBN(1);
		b1.setName("Last Wish");
		b1.setPrice(500);
		
		Books b2=new Books();
		b2.setISBN(2);
		b2.setName("Half Girl Friend");
		b2.setPrice(1000);
		
		Books b3=new Books();
		b3.setISBN(3);
		b3.setName("Three mistakes in my life");
		b3.setPrice(2000);
		
		Books b4=new Books();
		b4.setISBN(4);
		b4.setName("Two States");
		b4.setPrice(2000);
		
		Authors a1=new Authors();
		a1.setID(1);
		a1.setName("paramitha");
		List<Books> list1=new ArrayList<>();
		list1.add(b1);
		list1.add(b2);
		a1.setBooks(list1);
		
		Authors a2=new Authors();
		a2.setID(2);
		a2.setName("chethan bhagat");
		List<Books> list2=new ArrayList<>();
		list2.add(b3);
		list2.add(b4);
		a2.setBooks(list2);
		
		entityManager.persist(a1);
		entityManager.persist(a2);
		
		entityManager.getTransaction().commit();
		entityManager.close();
		factory.close();
		
	}

}

