package com.lti.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Books 
{
	@Id
	@Column(name="Book_id")
	private int ISBN;
	@Column(name="Book_name")
	private String Name;
	@Column(name="Book_price")
	private double price;
	@ManyToMany(mappedBy="books")
	private List<Authors> authors;
	public List<Authors> getAuthors() {
		return authors;
	}
	public void setAuthors(List<Authors> authors) {
		this.authors = authors;
	}
	public Books(int iSBN, String name, double price) {
		super();
		ISBN = iSBN;
		Name = name;
		this.price = price;
	}
	public Books() {
		super();
	}
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Books [ISBN=" + ISBN + ", Name=" + Name + ", price=" + price + "]";
	}
	
}
