package com.lti.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Authors
{
	@Id
	@Column(name="author_id")
	private int ID;
	@Column(name="author_name")
	private String name;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="books_authors")
	private List<Books> books;

public List<Books> getBooks() {
		return books;
	}

	public void setBooks(List<Books> books) {
		this.books = books;
	}

public Authors(int iD, String name) {
	super();
	ID = iD;
	this.name = name;
}

@Override
public String toString() {
	return "Authors [ID=" + ID + ", name=" + name + "]";
}

public Authors() {
	super();
}

public int getID() {
	return ID;
}
public void setID(int iD) {
	ID = iD;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
