package com.lti.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table (name="Saving_table")
public class Saving extends Account
{
	private int roi;

	public int getRoi() {
		return roi;
	}

	public void setRoi(int roi) {
		this.roi = roi;
	}

	public Saving(int roi) {
		super();
		this.roi = roi;
	}

	public Saving() {
		super();
	}

	public Saving(int accountId, String accountHolder, double balance) {
		super(accountId, accountHolder, balance);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Saving [roi=" + roi + "]";
	}
	
}
