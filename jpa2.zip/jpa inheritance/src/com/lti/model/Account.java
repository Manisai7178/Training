package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="account_table")
public class Account 
{
	@Id
	@Column(name="account_id")
	private int accountId;
	@Column(name="account_name")
	private String accountHolder;
	@Column(name="account_balance")
	private double balance;
	public Account() {
		super();
	}
	public Account(int accountId, String accountHolder, double balance) {
		super();
		this.accountId = accountId;
		this.accountHolder = accountHolder;
		this.balance = balance;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
}
