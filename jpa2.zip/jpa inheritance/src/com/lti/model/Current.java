package com.lti.model;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table (name="Current_table")
public class Current extends Account
{
	private int overdraft;

	public int getOverdraft() {
		return overdraft;
	}

	public void setOverdraft(int overdraft) {
		this.overdraft = overdraft;
	}

	public Current() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Current(int accountId, String accountHolder, double balance) {
		super(accountId, accountHolder, balance);
		this.overdraft = overdraft;
	}

	public Current(int overdraft) {
		super();
		this.overdraft = overdraft;
	}

	
	
	
}
